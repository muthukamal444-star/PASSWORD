const passwordInput = document.querySelector('#password');
const strengthText = document.querySelector('#strengthText');
const meter = document.querySelector('.meter');
const meterFill = document.querySelector('#meterFill');
const scoreEl = document.querySelector('#score');
const crackHint = document.querySelector('#crackHint');
const feedback = document.querySelector('#feedback');

const commonPasswords = new Set([
  'password','password1','123456','123456789','qwerty','letmein','welcome',
  'admin','iloveyou','abc123','monkey','dragon','football','master'
]);
const sequences = ['123456','abcdef','qwerty','asdfgh','zxcvbn','password'];

function analyze(pw) {
  if (!pw) return {score:0,label:'Not evaluated',checks:{},advice:'Enter a password to begin'};
  const checks = {
    length: pw.length >= 12,
    upper: /[a-z]/.test(pw) && /[A-Z]/.test(pw),
    number: /\d/.test(pw),
    symbol: /[^A-Za-z0-9]/.test(pw),
    pattern: !/(.)\1{2,}/.test(pw) && !sequences.some(s => pw.toLowerCase().includes(s)) && !commonPasswords.has(pw.toLowerCase())
  };
  const pool = (/[a-z]/.test(pw)?26:0) + (/[A-Z]/.test(pw)?26:0) +
    (/\d/.test(pw)?10:0) + (/[^A-Za-z0-9]/.test(pw)?32:0);
  let entropy = pw.length * Math.log2(Math.max(pool, 1));
  if (commonPasswords.has(pw.toLowerCase())) entropy = 0;
  if (/(.)\1{2,}/.test(pw) || sequences.some(s => pw.toLowerCase().includes(s))) entropy *= .45;
  // A transparent educational heuristic, not a breach-database or cracking-time test.
  let score = Math.round(Math.min(100, entropy / 1.15));
  if (!checks.length) score = Math.min(score, 45);
  if (!checks.pattern) score = Math.min(score, 35);
  const passed = Object.values(checks).filter(Boolean).length;
  if (passed <= 2) score = Math.min(score, 49);
  const label = score >= 80 ? 'Very strong' : score >= 60 ? 'Strong' : score >= 35 ? 'Fair' : 'Weak';
  let advice = 'Good work. Keep it unique to one account and store it in a password manager.';
  if (!checks.length) advice = 'Use at least 12 characters; 16 or more is even better.';
  else if (!checks.pattern) advice = 'Avoid common words, keyboard sequences, and repeated characters.';
  else if (!checks.upper || !checks.number || !checks.symbol) advice = 'Add variety, or use a longer randomly generated passphrase.';
  return {score,label,checks,advice};
}
function render() {
  const result = analyze(passwordInput.value);
  strengthText.textContent = result.label;
  strengthText.style.color = result.score >= 80 ? 'var(--green)' : result.score >= 60 ? 'var(--accent)' : result.score >= 35 ? 'var(--yellow)' : 'var(--red)';
  meterFill.style.width = result.score + '%';
  meterFill.style.background = result.score >= 80 ? 'var(--green)' : result.score >= 60 ? 'var(--accent)' : result.score >= 35 ? 'var(--yellow)' : 'var(--red)';
  meter.setAttribute('aria-valuenow', result.score);
  scoreEl.textContent = result.score + ' / 100';
  crackHint.textContent = passwordInput.value ? 'Approximate heuristic score' : 'Enter a password to begin';
  feedback.textContent = result.advice;
  document.querySelectorAll('[data-check]').forEach(item => {
    const passed = !!result.checks[item.dataset.check];
    item.classList.toggle('pass', passed);
    item.querySelector('.check-icon').textContent = passed ? '✓' : '○';
  });
}
passwordInput.addEventListener('input', render);
document.querySelector('#toggle').addEventListener('click', () => {
  const show = passwordInput.type === 'password';
  passwordInput.type = show ? 'text' : 'password';
  document.querySelector('#toggle').textContent = show ? 'Hide' : 'Show';
  document.querySelector('#toggle').setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});

const lengthInput = document.querySelector('#passLength');
lengthInput.addEventListener('input', () => document.querySelector('#lengthValue').textContent = lengthInput.value);
function secureIndex(max) {
  const limit = Math.floor(0x100000000 / max) * max;
  const arr = new Uint32Array(1);
  do { crypto.getRandomValues(arr); } while (arr[0] >= limit);
  return arr[0] % max;
}
function generatePassword() {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const digits = '23456789';
  const symbols = '!@#$%^&*()-_=+?';
  let alphabet = upper + lower;
  const required = [upper[secureIndex(upper.length)], lower[secureIndex(lower.length)]];
  if (document.querySelector('#includeNumbers').checked) {
    alphabet += digits; required.push(digits[secureIndex(digits.length)]);
  }
  if (document.querySelector('#includeSymbols').checked) {
    alphabet += symbols; required.push(symbols[secureIndex(symbols.length)]);
  }
  const length = Math.max(Number(lengthInput.value), required.length);
  while (required.length < length) required.push(alphabet[secureIndex(alphabet.length)]);
  for (let i = required.length - 1; i > 0; i--) {
    const j = secureIndex(i + 1); [required[i], required[j]] = [required[j], required[i]];
  }
  return required.join('');
}
document.querySelector('#generate').addEventListener('click', () => {
  document.querySelector('#generated').textContent = generatePassword();
  document.querySelector('#copy').disabled = false;
  document.querySelector('#copyFeedback').textContent = 'Generated locally. Save it in a password manager.';
});
document.querySelector('#copy').addEventListener('click', async () => {
  const value = document.querySelector('#generated').textContent;
  try {
    await navigator.clipboard.writeText(value);
    document.querySelector('#copyFeedback').textContent = 'Copied to clipboard.';
  } catch {
    document.querySelector('#copyFeedback').textContent = 'Clipboard access unavailable. Select and copy the password manually.';
  }
});
render();
