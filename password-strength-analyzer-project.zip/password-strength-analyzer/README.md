# Password Strength Analyzer

A beginner-friendly, responsive password security project built with HTML, CSS, and vanilla JavaScript.

## Features
- Password length and character variety checks
- Heuristic strength score and improvement feedback
- Checks for common passwords, simple sequences, and repeated characters
- Secure password generation using the browser Web Crypto API (`crypto.getRandomValues`)
- Adjustable generated-password length and optional numbers/symbols
- Copy generated password to clipboard
- Responsive layout and privacy notice

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Enter a test password or generate a new one.

No installation or backend is required. For clipboard access, some browsers require a secure context (HTTPS or localhost).

## Project structure
- `index.html` — page structure
- `style.css` — styling and responsive layout
- `script.js` — analysis and password generation logic

## Important security notes
- Passwords entered in the analyzer are processed only in the browser. This project does not transmit or store them.
- The score is an educational heuristic, not a real password-cracking estimate and not a check against breached-password databases.
- Character variety alone does not guarantee strength. Prefer long, unique, randomly generated passwords or passphrases.
- Do not add real account passwords to a demo project or deploy it as an authentication system.
- The optional password-history feature is intentionally not implemented. In a real authentication system, password reuse prevention must be designed server-side with careful privacy and security controls; never store plaintext passwords.
